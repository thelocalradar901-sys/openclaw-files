"""
config.py – OpenClaw configuration
All cities, API keys, DB credentials, and scrape sources live here.

To add a new venue: add an entry to the city's scrape_sources list.
Use "source_type": "html_auto" for any new venue — no selectors needed.
"""

import os

# ─── Logging ────────────────────────────────────────────────────────────────
LOG_LEVEL = os.getenv("OPENCLAW_LOG_LEVEL", "INFO")

# ─── Database ───────────────────────────────────────────────────────────────
DB = {
    "host":     os.getenv("WP_DB_HOST", "localhost"),
    "port":     int(os.getenv("WP_DB_PORT", 3306)),
    "user":     os.getenv("WP_DB_USER", "wpuser"),
    "password": os.getenv("WP_DB_PASSWORD", ""),
    "database": os.getenv("WP_DB_NAME", "wordpress"),
    "charset":  "utf8mb4",
}

WP_PREFIX = os.getenv("WP_PREFIX", "wp_")

# ─── Ticketmaster ───────────────────────────────────────────────────────────
TICKETMASTER_API_KEY = os.getenv("TICKETMASTER_API_KEY", "")

# ─── Ollama / Qwen3 ─────────────────────────────────────────────────────────
OLLAMA_HOST    = os.getenv("OLLAMA_HOST", "http://localhost:11434")
OLLAMA_MODEL   = os.getenv("OLLAMA_MODEL", "qwen3:14b")
OLLAMA_TIMEOUT = int(os.getenv("OLLAMA_TIMEOUT", 60))

# ─── Scheduler intervals (seconds) ──────────────────────────────────────────
TICKETMASTER_INTERVAL = int(os.getenv("TM_INTERVAL", 3600))    # every 1 hour
SCRAPER_INTERVAL      = int(os.getenv("SCRAPER_INTERVAL", 7200))  # every 2 hours

# ─── Cities & Sources ───────────────────────────────────────────────────────
# source_type options:
#   "html_auto"         — new universal scraper, just needs a URL
#   "tec_rest"          — TEC REST API (needs tec_rest_base)
#   "seetickets_widget" — SeeTickets widget (needs widget_selector)
#   "json_api"          — paginated JSON API (needs api_url)
#   "generic_html"      — CSS selector scraper (needs event_container_selector)

CITIES = [
    {
        "name": "Memphis",
        "slug": "memphis",
        "ticketmaster_dma_id": "322",
        "wp_site_id": 1,
        "default_category_slug": "memphis-events",
        "scrape_sources": [
            {
                "name": "Crosstown Concourse",
                "url": "https://crosstownconcourse.com/events",
                "source_type": "tec_rest",
                "tec_rest_base": "https://crosstownconcourse.com/wp-json/tribe/events/v1/events",
            },
            {
                "name": "S2F Events",
                "url": "https://s2fevents.com",
                "source_type": "seetickets_widget",
                "widget_selector": ".seetickets-list-event-section",
            },
            {
                "name": "Hernando's Hideaway",
                "url": "https://www.hernandoshideaway.com/events",
                "source_type": "generic_html",
                "event_container_selector": ".event-item",
                "title_selector": ".event-title",
                "date_selector": ".event-date",
                "description_selector": ".event-description",
            },
            {
                "name": "Memphis Flyer",
                "url": "https://www.memphisflyer.com/memphis/EventSearch",
                "source_type": "json_api",
                "api_url": "https://www.memphisflyer.com/memphis/EventSearch?format=json&page={page}",
                "pagination": True,
                "max_pages": 5,
            },
            {
                "name": "Levitt Shell",
                "url": "https://levittshell.org/events/",
                "source_type": "html_auto",
            },
            {
                "name": "Agricenter International",
                "url": "https://www.agricenter.org/events",
                "source_type": "html_auto",
            },
            {
                "name": "Graceland",
                "url": "https://www.graceland.com/events",
                "source_type": "html_auto",
            },
            {
                "name": "Orpheum Theatre",
                "url": "https://www.orpheum-memphis.com/events",
                "source_type": "html_auto",
            },
            {
                "name": "Memphis Botanic Garden",
                "url": "https://www.memphisbotanicgarden.com/events",
                "source_type": "html_auto",
            },
        ],
    },
    {
        "name": "Denver",
        "slug": "denver",
        "ticketmaster_dma_id": "302",
        "wp_site_id": 1,
        "default_category_slug": "denver-events",
        "scrape_sources": [
            {
                "name": "Red Rocks Amphitheatre",
                "url": "https://www.redrocksonline.com/events/",
                "source_type": "html_auto",
            },
            {
                "name": "Ogden Theatre",
                "url": "https://www.ogdentheatre.com/events",
                "source_type": "html_auto",
            },
            {
                "name": "Meow Wolf Denver",
                "url": "https://meowwolf.com/visit/denver/events",
                "source_type": "html_auto",
            },
            {
                "name": "Denver Art Museum",
                "url": "https://www.denverartmuseum.org/en/events",
                "source_type": "html_auto",
            },
            {
                "name": "Mission Ballroom",
                "url": "https://www.missionballroom.com/events",
                "source_type": "html_auto",
            },
        ],
    },
    {
        "name": "Nashville",
        "slug": "nashville",
        "ticketmaster_dma_id": "324",
        "wp_site_id": 1,
        "default_category_slug": "nashville-events",
        "scrape_sources": [
            {
                "name": "Ryman Auditorium",
                "url": "https://ryman.com/events/",
                "source_type": "html_auto",
            },
            {
                "name": "Ascend Amphitheater",
                "url": "https://www.ascendamphitheater.com/events",
                "source_type": "html_auto",
            },
            {
                "name": "Brooklyn Bowl Nashville",
                "url": "https://www.brooklynbowl.com/nashville/events",
                "source_type": "html_auto",
            },
            {
                "name": "Nashville Fairgrounds",
                "url": "https://www.nashvillefairgrounds.com/events",
                "source_type": "html_auto",
            },
        ],
    },
    {
        "name": "Birmingham",
        "slug": "birmingham",
        "ticketmaster_dma_id": "630",
        "wp_site_id": 1,
        "default_category_slug": "birmingham-events",
        "scrape_sources": [
            {
                "name": "Iron City",
                "url": "https://ironcitybham.com/events/",
                "source_type": "html_auto",
            },
            {
                "name": "Saturn Birmingham",
                "url": "https://www.saturnbirmingham.com/events/",
                "source_type": "html_auto",
            },
            {
                "name": "Avondale Brewing",
                "url": "https://avondalebrewing.com/events",
                "source_type": "html_auto",
            },
            {
                "name": "Alabama Theatre",
                "url": "https://www.alabamatheatre.com/events",
                "source_type": "html_auto",
            },
        ],
    },
]

# ─── TEC Category Mapping ────────────────────────────────────────────────────
CATEGORY_KEYWORDS = {
    "music":       ["concert", "live music", "band", "show", "festival", "dj", "jazz", "blues", "hip hop", "country", "rock", "indie", "rap"],
    "arts":        ["art", "gallery", "exhibit", "museum", "theatre", "theater", "dance", "opera", "ballet", "film", "cinema", "comedy"],
    "food-drink":  ["food", "drink", "wine", "beer", "cocktail", "tasting", "dining", "restaurant", "brunch", "happy hour", "bbq"],
    "sports":      ["game", "match", "tournament", "grizzlies", "hustle", "tigers", "memphis", "nba", "nfl", "mlb", "nhl", "mls", "soccer", "football", "basketball", "baseball"],
    "fitness":     ["run", "race", "5k", "marathon", "yoga", "cycling", "bike", "hike", "triathlon", "crossfit", "fitness", "workout"],
    "community":   ["community", "volunteer", "charity", "fundraiser", "neighborhood", "civic", "meeting", "town hall"],
    "family":      ["family", "kids", "children", "youth", "parent", "toddler", "baby"],
    "nightlife":   ["nightlife", "club", "bar", "lounge", "karaoke", "trivia", "drag", "dance"],
    "outdoors":    ["outdoor", "park", "garden", "nature", "trail", "kayak", "canoe", "camping", "fishing"],
    "business":    ["networking", "conference", "seminar", "workshop", "professional", "startup", "entrepreneur"],
    "education":   ["lecture", "class", "course", "workshop", "learning", "tour", "talk", "panel"],
    "holiday":     ["holiday", "christmas", "halloween", "thanksgiving", "new year", "valentine", "easter", "fourth of july"],
}

# ─── Deduplication ───────────────────────────────────────────────────────────
DEDUP_FIELDS = ["title", "start_date", "venue_name"]

# ─── Image sideloading ───────────────────────────────────────────────────────
SIDELOAD_IMAGES = True
IMAGE_TIMEOUT   = 15

# ─── Ticketmaster filters ────────────────────────────────────────────────────
TM_SEGMENTS = ["Music", "Arts & Theatre", "Sports", "Family", "Miscellaneous"]
TM_RADIUS   = "50"
TM_UNIT     = "miles"
TM_SIZE     = 200
