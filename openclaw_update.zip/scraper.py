"""
scraper.py – OpenClaw modular HTML scraper engine
Handles five source types:
  - tec_rest:          TEC REST API (other WP sites)
  - seetickets_widget: SeeTickets embedded widgets
  - json_api:          Generic paginated JSON APIs (Memphis Flyer, etc.)
  - generic_html:      CSS-selector based HTML scraping with Ollama fallback
  - html_auto:         Auto-detecting scraper (iCal → JSON-LD → heuristic → Ollama)
                       Use this for any new venue — no selectors needed.
"""

import logging
import re
import time
from datetime import datetime

import requests
from bs4 import BeautifulSoup

log = logging.getLogger("openclaw.scraper")

HEADERS = {
    "User-Agent": "OpenClaw/1.0 (+https://thelocalradar.com)",
    "Accept": "text/html,application/xhtml+xml,application/xhtml+xml,*/*",
}


def scrape_source(source: dict, city: dict) -> list[dict]:
    stype = source.get("source_type", "generic_html")
    log.info("Scraping '%s' (%s) for %s", source["name"], stype, city["name"])

    try:
        if stype == "tec_rest":
            return _scrape_tec_rest(source, city)
        elif stype == "seetickets_widget":
            return _scrape_seetickets(source, city)
        elif stype == "json_api":
            return _scrape_json_api(source, city)
        elif stype == "generic_html":
            return _scrape_generic_html(source, city)
        elif stype == "html_auto":
            return _scrape_html_auto(source, city)
        else:
            log.warning("Unknown source_type '%s' for %s", stype, source["name"])
            return []
    except Exception as e:
        log.error("Scraper crashed for '%s': %s", source["name"], e, exc_info=True)
        return []


# ─── html_auto: universal auto-detecting scraper ─────────────────────────────

def _scrape_html_auto(source: dict, city: dict) -> list[dict]:
    """
    4-tier auto-detection. Add any venue with just a URL — no selectors needed.
    Tier 1: iCal feed
    Tier 2: JSON-LD structured data
    Tier 3: Heuristic CSS pattern matching
    Tier 4: Ollama/Qwen3 AI extraction
    """
    url = source["url"]
    try:
        resp = requests.get(url, headers=HEADERS, timeout=20)
        resp.raise_for_status()
    except Exception as e:
        log.warning("html_auto fetch failed for %s: %s", source["name"], e)
        return []

    html = resp.text

    # Tier 1: iCal
    ical_url = _detect_ical(html, url)
    if ical_url:
        events = _parse_ical(ical_url, source, city)
        if events:
            log.info("[%s] iCal tier: %d events", source["name"], len(events))
            return events

    # Tier 2: JSON-LD
    events = _parse_jsonld(html, source, city)
    if events:
        log.info("[%s] JSON-LD tier: %d events", source["name"], len(events))
        return events

    # Tier 3: Heuristic HTML
    events = _parse_heuristic(html, url, source, city)
    if events:
        log.info("[%s] Heuristic tier: %d events", source["name"], len(events))
        return events

    # Tier 4: Ollama fallback
    log.info("[%s] Falling back to Ollama", source["name"])
    events = _ollama_extract(html, source, city)
    if events:
        log.info("[%s] Ollama tier: %d events", source["name"], len(events))
    else:
        log.warning("[%s] All tiers failed", source["name"])
    return events


def _detect_ical(html: str, base_url: str):
    soup = BeautifulSoup(html, "html.parser")
    tag = soup.find("link", {"type": "text/calendar"})
    if tag and tag.get("href"):
        href = tag["href"]
        return href if href.startswith("http") else _abs(href, base_url)
    for a in soup.find_all("a", href=True):
        if ".ics" in a["href"]:
            href = a["href"]
            return href if href.startswith("http") else _abs(href, base_url)
    return None


def _parse_ical(ical_url: str, source: dict, city: dict) -> list[dict]:
    try:
        from icalendar import Calendar
        from datetime import date, timezone
        resp = requests.get(ical_url, headers=HEADERS, timeout=20)
        resp.raise_for_status()
        cal = Calendar.from_ical(resp.content)
        events = []
        for component in cal.walk():
            if component.name != "VEVENT":
                continue
            title = str(component.get("SUMMARY", "")).strip()
            dtstart = component.get("DTSTART")
            if not title or not dtstart:
                continue
            dt = dtstart.dt
            if isinstance(dt, date) and not isinstance(dt, datetime):
                dt = datetime(dt.year, dt.month, dt.day)
            start_date = dt.strftime("%Y-%m-%d %H:%M:%S")
            dtend = component.get("DTEND")
            end_dt = dtend.dt if dtend else dt
            if isinstance(end_dt, date) and not isinstance(end_dt, datetime):
                end_dt = datetime(end_dt.year, end_dt.month, end_dt.day)
            end_date = end_dt.strftime("%Y-%m-%d %H:%M:%S")
            events.append(_make_event(
                title=title,
                description=str(component.get("DESCRIPTION", "")).strip(),
                start_date=start_date,
                end_date=end_date,
                venue_name=str(component.get("LOCATION", source["name"])).strip(),
                ticket_url=str(component.get("URL", "")).strip(),
                source=source, city=city,
            ))
        return events
    except Exception as e:
        log.warning("iCal parse failed for %s: %s", ical_url, e)
        return []


def _parse_jsonld(html: str, source: dict, city: dict) -> list[dict]:
    import json
    soup = BeautifulSoup(html, "html.parser")
    events = []
    for script in soup.find_all("script", {"type": "application/ld+json"}):
        try:
            data = json.loads(script.string or "")
        except Exception:
            continue
        items = data if isinstance(data, list) else [data]
        if isinstance(data, dict) and "@graph" in data:
            items = data["@graph"]
        for item in items:
            if not isinstance(item, dict):
                continue
            if "Event" not in str(item.get("@type", "")):
                continue
            title = item.get("name", "").strip()
            start_raw = item.get("startDate", "")
            if not title or not start_raw:
                continue
            location = item.get("location", {})
            venue_name = location.get("name", source["name"]) if isinstance(location, dict) else source["name"]
            events.append(_make_event(
                title=title,
                description=item.get("description", "").strip(),
                start_date=_normalize_dt(start_raw),
                end_date=_normalize_dt(item.get("endDate", start_raw)),
                venue_name=venue_name,
                ticket_url=item.get("url", "").strip(),
                source=source, city=city,
            ))
    return events


_AUTO_EVENT_SELECTORS = [
    "[class*='event-item']", "[class*='event_item']", "[class*='eventCard']",
    "[class*='event-card']", "[class*='event-list-item']", "[class*='tribe-event']",
    "[class*='tribe_event']", "article[class*='event']", "li[class*='event']", ".vevent",
]

def _parse_heuristic(html: str, base_url: str, source: dict, city: dict) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    containers = []
    for sel in _AUTO_EVENT_SELECTORS:
        found = soup.select(sel)
        if found:
            containers = found
            break
    if not containers:
        return []
    events = []
    for container in containers[:50]:
        title_el = container.select_one("h1,h2,h3,[class*='title'],[class*='summary']")
        if not title_el:
            continue
        title = title_el.get_text(strip=True)
        date_el = container.select_one("time,[class*='date'],[class*='tribe-event-date']")
        date_str = ""
        if date_el:
            date_str = date_el.get("datetime", "") or date_el.get_text(strip=True)
        start_date = _parse_fuzzy_date(date_str)
        a_tag = container.find("a", href=True)
        ticket_url = ""
        if a_tag:
            href = a_tag["href"]
            ticket_url = href if href.startswith("http") else _abs(href, base_url)
        p_tag = container.find("p")
        desc = p_tag.get_text(strip=True) if p_tag else ""
        events.append(_make_event(
            title=title, description=desc, start_date=start_date,
            end_date=start_date, venue_name=source["name"],
            ticket_url=ticket_url, source=source, city=city,
        ))
    return events


def _make_event(title, description, start_date, end_date, venue_name, ticket_url, source, city) -> dict:
    return {
        "title": title, "description": description,
        "start_date": start_date, "end_date": end_date,
        "venue_name": venue_name, "venue_address": "",
        "venue_city": city["name"], "venue_state": "", "venue_zip": "",
        "organizer_name": "", "image_url": "", "ticket_url": ticket_url,
        "cost": "", "source_name": source["name"], "city_slug": city["slug"],
        "categories": [], "tags": [], "external_id": "",
    }


def _abs(href: str, base_url: str) -> str:
    from urllib.parse import urljoin
    return urljoin(base_url, href)


# ─── TEC REST API ─────────────────────────────────────────────────────────────

def _scrape_tec_rest(source: dict, city: dict) -> list[dict]:
    base = source.get("tec_rest_base")
    if not base:
        log.error("tec_rest source '%s' missing tec_rest_base", source["name"])
        return []
    events = []
    page = 1
    while True:
        try:
            resp = requests.get(base, params={"page": page, "per_page": 50}, headers=HEADERS, timeout=20)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            log.warning("TEC REST error page %d for %s: %s", page, source["name"], e)
            break
        raw_events = data.get("events", [])
        if not raw_events:
            break
        for raw in raw_events:
            ev = _normalize_tec_rest_event(raw, source, city)
            if ev:
                events.append(ev)
        if not data.get("next_rest_url") or page >= data.get("total_pages", 1):
            break
        page += 1
        time.sleep(0.5)
    return events


def _normalize_tec_rest_event(raw: dict, source: dict, city: dict) -> dict | None:
    title = (raw.get("title") or {}).get("rendered", "").strip()
    if not title:
        title = raw.get("title", "").strip()
    if not title:
        return None
    description = BeautifulSoup(
        (raw.get("description") or {}).get("rendered", "") or raw.get("description", ""),
        "html.parser"
    ).get_text(separator=" ", strip=True)
    start_date = _normalize_dt(raw.get("start_date") or raw.get("start_date_details", {}).get("date"))
    end_date   = _normalize_dt(raw.get("end_date") or raw.get("end_date_details", {}).get("date") or start_date)
    venue = (raw.get("venue") or {})
    image_url = ""
    if raw.get("image"):
        image_url = (raw["image"].get("url") or raw["image"].get("sizes", {}).get("large", {}).get("url", ""))
    return {
        "title": title, "description": description,
        "start_date": start_date, "end_date": end_date,
        "venue_name": venue.get("venue", ""), "venue_address": venue.get("address", ""),
        "venue_city": venue.get("city", ""), "venue_state": venue.get("stateprovince", ""),
        "venue_zip": venue.get("zip", ""), "organizer_name": "",
        "image_url": image_url, "ticket_url": raw.get("url", ""),
        "cost": raw.get("cost", ""), "source_name": source["name"],
        "city_slug": city["slug"], "categories": [], "tags": [],
        "external_id": f"tec_{raw.get('id', '')}",
    }


# ─── SeeTickets widget ────────────────────────────────────────────────────────

def _scrape_seetickets(source: dict, city: dict) -> list[dict]:
    try:
        resp = requests.get(source["url"], headers=HEADERS, timeout=20)
        resp.raise_for_status()
    except Exception as e:
        log.warning("SeeTickets fetch failed for %s: %s", source["name"], e)
        return []
    soup = BeautifulSoup(resp.text, "html.parser")
    selector = source.get("widget_selector", ".seetickets-list-event-section")
    containers = soup.select(selector)
    events = []
    for container in containers:
        ev = _parse_seetickets_container(container, source, city)
        if ev:
            events.append(ev)
    return events


def _parse_seetickets_container(container, source: dict, city: dict) -> dict | None:
    title_el = container.select_one(".seetickets-list-event-name, h2, h3, .event-name")
    date_el  = container.select_one(".seetickets-list-event-date, .event-date, time")
    venue_el = container.select_one(".seetickets-list-event-venue, .venue-name")
    link_el  = container.select_one("a[href]")
    title = title_el.get_text(strip=True) if title_el else ""
    if not title:
        return None
    date_str   = date_el.get_text(strip=True) if date_el else ""
    start_date = _parse_fuzzy_date(date_str)
    venue_name = venue_el.get_text(strip=True) if venue_el else ""
    ticket_url = link_el["href"] if link_el else ""
    img_el = container.select_one("img")
    image_url = img_el.get("src", "") if img_el else ""
    description = container.get_text(separator=" ", strip=True)
    return {
        "title": title, "description": description,
        "start_date": start_date, "end_date": start_date,
        "venue_name": venue_name, "venue_address": "",
        "venue_city": city["name"], "venue_state": "", "venue_zip": "",
        "organizer_name": "", "image_url": image_url, "ticket_url": ticket_url,
        "cost": "", "source_name": source["name"], "city_slug": city["slug"],
        "categories": [], "tags": [], "external_id": "",
    }


# ─── JSON API ─────────────────────────────────────────────────────────────────

def _scrape_json_api(source: dict, city: dict) -> list[dict]:
    api_url_template = source.get("api_url", source["url"])
    paginate  = source.get("pagination", False)
    max_pages = source.get("max_pages", 1)
    events = []
    for page in range(1, max_pages + 1):
        url = api_url_template.format(page=page)
        try:
            resp = requests.get(url, headers={**HEADERS, "Accept": "application/json"}, timeout=20)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            log.warning("JSON API page %d failed for %s: %s", page, source["name"], e)
            break
        raw_events = _extract_json_events(data)
        if not raw_events:
            break
        for raw in raw_events:
            ev = _normalize_json_api_event(raw, source, city)
            if ev:
                events.append(ev)
        if not paginate:
            break
        time.sleep(0.5)
    return events


def _extract_json_events(data) -> list:
    if isinstance(data, list):
        return data
    for key in ("events", "items", "data", "results", "event_list"):
        if key in data and isinstance(data[key], list):
            return data[key]
    return []


def _normalize_json_api_event(raw: dict, source: dict, city: dict) -> dict | None:
    title = (raw.get("title") or raw.get("name") or raw.get("event_name") or raw.get("event_title") or "").strip()
    if not title:
        return None
    description = BeautifulSoup(raw.get("description") or raw.get("summary") or raw.get("body") or "", "html.parser").get_text(separator=" ", strip=True)
    start_raw = raw.get("start_date") or raw.get("startDate") or raw.get("event_date") or raw.get("date") or raw.get("start") or ""
    end_raw   = raw.get("end_date") or raw.get("endDate") or raw.get("end") or start_raw
    start_date = _normalize_dt(start_raw)
    end_date   = _normalize_dt(end_raw)
    venue_name = raw.get("venue") or raw.get("venue_name") or raw.get("location") or ""
    if isinstance(venue_name, dict):
        venue_name = venue_name.get("name", "")
    image_url = raw.get("image") or raw.get("image_url") or raw.get("thumbnail") or raw.get("photo") or ""
    if isinstance(image_url, dict):
        image_url = image_url.get("url", "")
    ticket_url = raw.get("url") or raw.get("ticket_url") or raw.get("link") or ""
    return {
        "title": title, "description": description,
        "start_date": start_date, "end_date": end_date,
        "venue_name": str(venue_name), "venue_address": "",
        "venue_city": city["name"], "venue_state": "", "venue_zip": "",
        "organizer_name": "", "image_url": str(image_url), "ticket_url": str(ticket_url),
        "cost": str(raw.get("cost") or raw.get("price") or ""),
        "source_name": source["name"], "city_slug": city["slug"],
        "categories": [], "tags": [], "external_id": str(raw.get("id") or ""),
    }


# ─── Generic HTML ─────────────────────────────────────────────────────────────

def _scrape_generic_html(source: dict, city: dict) -> list[dict]:
    try:
        resp = requests.get(source["url"], headers=HEADERS, timeout=20)
        resp.raise_for_status()
    except Exception as e:
        log.warning("Generic HTML fetch failed for %s: %s", source["name"], e)
        return []
    soup = BeautifulSoup(resp.text, "html.parser")
    container_sel = source.get("event_container_selector")
    if container_sel:
        containers = soup.select(container_sel)
        if containers:
            events = []
            for container in containers:
                ev = _parse_structured_container(container, source, city)
                if ev:
                    events.append(ev)
            return events
    log.info("No container selector match for %s — falling back to Ollama", source["name"])
    return _ollama_extract(resp.text, source, city)


def _parse_structured_container(container, source: dict, city: dict) -> dict | None:
    title_sel = source.get("title_selector", "h2, h3, .event-title, .title")
    date_sel  = source.get("date_selector", ".event-date, time, .date")
    desc_sel  = source.get("description_selector", ".event-description, .description, p")
    title_el  = container.select_one(title_sel)
    date_el   = container.select_one(date_sel)
    desc_el   = container.select_one(desc_sel)
    link_el   = container.select_one("a[href]")
    img_el    = container.select_one("img")
    title = title_el.get_text(strip=True) if title_el else ""
    if not title:
        return None
    date_str    = date_el.get_text(strip=True) if date_el else ""
    start_date  = _parse_fuzzy_date(date_str)
    description = desc_el.get_text(separator=" ", strip=True) if desc_el else ""
    ticket_url  = link_el["href"] if link_el else ""
    image_url   = img_el.get("src", "") if img_el else ""
    return {
        "title": title, "description": description,
        "start_date": start_date, "end_date": start_date,
        "venue_name": "", "venue_address": "",
        "venue_city": city["name"], "venue_state": "", "venue_zip": "",
        "organizer_name": "", "image_url": image_url, "ticket_url": ticket_url,
        "cost": "", "source_name": source["name"], "city_slug": city["slug"],
        "categories": [], "tags": [], "external_id": "", "_needs_enrichment": True,
    }


# ─── Ollama / Qwen3 fallback ──────────────────────────────────────────────────

def _ollama_extract(html: str, source: dict, city: dict) -> list[dict]:
    try:
        import requests as req
        from config import OLLAMA_HOST, OLLAMA_MODEL, OLLAMA_TIMEOUT
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup(["script", "style", "nav", "footer", "header"]):
            tag.decompose()
        text = soup.get_text(separator="\n", strip=True)[:6000]
        prompt = f"""Extract all events from the following website text for {source['name']} in {city['name']}.
Return a JSON array. Each event object must have these exact keys:
title, description, start_date (YYYY-MM-DD HH:MM:SS or YYYY-MM-DD), end_date, venue_name, ticket_url, cost, image_url.
If a field is unknown, use an empty string. Return ONLY valid JSON, no other text.

Website text:
{text}"""
        response = req.post(
            f"{OLLAMA_HOST}/api/generate",
            json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False, "format": "json"},
            timeout=OLLAMA_TIMEOUT,
        )
        response.raise_for_status()
        raw_json = response.json().get("response", "[]")
        import json
        extracted = json.loads(raw_json)
        if not isinstance(extracted, list):
            extracted = extracted.get("events", [])
        events = []
        for item in extracted:
            title = (item.get("title") or "").strip()
            if not title:
                continue
            events.append({
                "title": title, "description": item.get("description", ""),
                "start_date": _normalize_dt(item.get("start_date", "")),
                "end_date": _normalize_dt(item.get("end_date", "") or item.get("start_date", "")),
                "venue_name": item.get("venue_name", ""), "venue_address": "",
                "venue_city": city["name"], "venue_state": "", "venue_zip": "",
                "organizer_name": "", "image_url": item.get("image_url", ""),
                "ticket_url": item.get("ticket_url", ""), "cost": item.get("cost", ""),
                "source_name": source["name"], "city_slug": city["slug"],
                "categories": [], "tags": [], "external_id": "",
            })
        log.info("Ollama extracted %d events from %s", len(events), source["name"])
        return events
    except Exception as e:
        log.error("Ollama extraction failed for %s: %s", source["name"], e, exc_info=True)
        return []


# ─── Date parsing helpers ─────────────────────────────────────────────────────

def _normalize_dt(raw) -> str:
    if not raw:
        return ""
    if isinstance(raw, (int, float)):
        try:
            return datetime.fromtimestamp(raw).strftime("%Y-%m-%d %H:%M:%S")
        except Exception:
            return ""
    raw = str(raw).strip().replace("Z", "+00:00")
    if re.match(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}", raw):
        return raw
    try:
        dt = datetime.fromisoformat(raw)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except ValueError:
        pass
    m = re.search(r"(\d{4}-\d{2}-\d{2})", raw)
    if m:
        return m.group(1) + " 00:00:00"
    return _parse_fuzzy_date(raw)


def _parse_fuzzy_date(text: str) -> str:
    if not text:
        return datetime.now().strftime("%Y-%m-%d 00:00:00")
    try:
        from dateutil import parser as dateparser
        dt = dateparser.parse(text, fuzzy=True)
        if dt:
            return dt.strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        pass
    return datetime.now().strftime("%Y-%m-%d 00:00:00")
