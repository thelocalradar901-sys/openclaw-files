#!/usr/bin/env python3
"""
OpenClaw – Local Radar Event Aggregation Daemon
Pulls from Ticketmaster API and custom HTML sources.
Writes directly to WordPress MySQL. Runs as a systemd service.
"""

import logging
import signal
import sys
import time

from scheduler import start_scheduler
from config import CITIES, LOG_LEVEL

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("/var/log/openclaw/openclaw.log"),
    ],
)
log = logging.getLogger("openclaw")


def handle_shutdown(signum, frame):
    log.info("Shutdown signal received. Exiting.")
    sys.exit(0)


def main():
    signal.signal(signal.SIGTERM, handle_shutdown)
    signal.signal(signal.SIGINT, handle_shutdown)

    log.info("OpenClaw starting up. Cities: %s", [c["name"] for c in CITIES])
    scheduler = start_scheduler()

    try:
        while True:
            time.sleep(60)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown()
        log.info("OpenClaw stopped.")


if __name__ == "__main__":
    main()
