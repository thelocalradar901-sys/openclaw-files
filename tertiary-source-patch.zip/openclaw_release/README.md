# Tertiary Source Auto-Enrichment Patch

Adds automatic creation of "tertiary" (info-only) sources for venues
Ticketmaster surfaces that aren't yet in wp_openclaw_sources, using
Google Places to resolve the venue's real website. Tertiary sources
are scraped on the normal schedule but only ever merge INTO an
existing Ticketmaster post (better image/description) -- they never
publish a standalone post of their own.

## Files

- `places.py` — new module, Google Places Find Place + Details lookup
- `tertiary_sources.py` — new module, auto-creates tertiary source rows
- `add_tier_column.py` — one-time DB migration (adds `tier` column)
- `apply_tertiary_patch.py` — patches ticketmaster.py + db.py automatically
- `config_addition.txt` — the one line to add to config.py by hand

## Deploy order

1. Add to `/etc/openclaw/openclaw.env`:
   ```
   GOOGLE_PLACES_API_KEY=your_key_here
   ```

2. Edit `config.py` per `config_addition.txt` (one line, near
   `TICKETMASTER_API_KEY`).

3. Copy `places.py`, `tertiary_sources.py`, `add_tier_column.py`,
   and `apply_tertiary_patch.py` into `/opt/openclaw/`.

4. Run the migration once:
   ```
   cd /opt/openclaw
   /opt/openclaw/venv/bin/python add_tier_column.py
   ```

5. Run the auto-patcher:
   ```
   cd /opt/openclaw
   /opt/openclaw/venv/bin/python apply_tertiary_patch.py
   ```
   This edits `ticketmaster.py` and `db.py` in place, after backing
   each up to `.bak`. It's idempotent -- safe to re-run, it'll just
   say "already patched" the second time.

6. If either patch step prints an ERROR instead of "patched
   successfully," it means your current file doesn't match the exact
   structure this script expects (e.g. you've made other unreleased
   edits to that file). In that case, no changes were made to the
   affected file -- apply the relevant `*_patch_instructions.txt`
   block by hand instead, using `view`/`str_replace` or your editor
   of choice.

7. Delete `test_places.py` from the server if it's still there -- it
   has the API key hardcoded for the one-off curl-replacement test
   and its job is done.

8. Restart the openclaw systemd service so ticketmaster.py's changes
   take effect on the next scheduled pull:
   ```
   sudo systemctl restart openclaw
   ```

## Verifying it worked

After the next TM pull for a city with an unrecognized venue (or
trigger one manually), check:

```sql
SELECT id, name, url, tier, status FROM wp_openclaw_sources WHERE tier='tertiary';
```

You should see new probation-status rows with `tier='tertiary'` and a
real URL (when Google Places found one) or a blank URL with a note in
`notes` saying it needs manual entry.

Once a tertiary source has a URL and gets fired/scraped, and its
events match an existing TM post by date+city+fuzzy title (the
existing `find_cross_source_match()` logic, unchanged), the TM post's
missing image/description should backfill via the existing
`_apply_image()` "fill only if empty" logic -- also unchanged.

If a tertiary source's scrape produces an event with NO matching TM
post, `db.py`'s new guard discards it (logged at INFO level as
"Discarding tertiary-source event with no TM match") rather than
creating a standalone post.
