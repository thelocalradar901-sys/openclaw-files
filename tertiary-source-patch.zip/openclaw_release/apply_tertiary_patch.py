#!/usr/bin/env python3
"""
apply_tertiary_patch.py — applies the tertiary-source feature's edits
to ticketmaster.py and db.py automatically, with .bak backups.

Run this AFTER copying places.py, tertiary_sources.py, and
add_tier_column.py into /opt/openclaw/, and AFTER running
add_tier_column.py and adding GOOGLE_PLACES_API_KEY to
/etc/openclaw/openclaw.env + config.py.

Usage:
  cd /opt/openclaw
  python3 apply_tertiary_patch.py

Safe to re-run -- it checks for its own markers before patching, so
running it twice is a no-op the second time instead of double-patching.
"""

import re
import shutil
import sys
from pathlib import Path

OPENCLAW_DIR = Path("/opt/openclaw")

TM_IMPORT_MARKER  = "from tertiary_sources import ensure_tertiary_source"
TM_LOOP_MARKER    = "ensure_tertiary_source(venue_name, venue_city, city[\"slug\"])"

DB_HELPER_MARKER  = "_is_tertiary_source"
DB_GUARD_MARKER   = "Discarding tertiary-source event with no TM match"


def backup(path: Path) -> None:
    bak = path.with_suffix(path.suffix + ".bak")
    if not bak.exists():
        shutil.copy2(path, bak)
        print(f"  backed up {path.name} -> {bak.name}")


def patch_ticketmaster() -> None:
    path = OPENCLAW_DIR / "ticketmaster.py"
    text = path.read_text()

    if TM_IMPORT_MARKER in text:
        print("ticketmaster.py already patched — skipping.")
        return

    backup(path)

    # 1. Add the import, right after the existing `import requests` line
    text = text.replace(
        "import requests\n",
        "import requests\n\n" + TM_IMPORT_MARKER + "\n",
        1
    )

    # 2. Hook into the raw_events loop inside pull_city()
    old_loop = (
        "        for raw in raw_events:\n"
        "            ev = _normalize(raw, city, tz, tz_name)\n"
        "            if ev:\n"
        "                events.append(ev)\n"
    )
    new_loop = (
        "        for raw in raw_events:\n"
        "            ev = _normalize(raw, city, tz, tz_name)\n"
        "            if ev:\n"
        "                events.append(ev)\n"
        "                venues = raw.get(\"_embedded\", {}).get(\"venues\", [{}])\n"
        "                venue  = venues[0] if venues else {}\n"
        "                venue_name = (venue.get(\"name\") or \"\").strip()\n"
        "                venue_city = (venue.get(\"city\", {}).get(\"name\") or \"\").strip()\n"
        "                if venue_name:\n"
        "                    " + TM_LOOP_MARKER + "\n"
    )

    if old_loop not in text:
        print("ERROR: could not find the expected raw_events loop in ticketmaster.py.")
        print("No changes made to this file — apply the patch manually using")
        print("ticketmaster_patch_instructions.txt instead.")
        return

    text = text.replace(old_loop, new_loop, 1)
    path.write_text(text)
    print("ticketmaster.py patched successfully.")


def patch_db() -> None:
    path = OPENCLAW_DIR / "db.py"
    text = path.read_text()

    if DB_HELPER_MARKER in text:
        print("db.py already patched — skipping.")
        return

    backup(path)

    helper_fn = '''

def _is_tertiary_source(conn, source_name: str) -> bool:
    """
    True if `source_name` (event.get("source_name")) belongs to a
    tertiary-tier source. Tertiary sources exist purely to enrich
    existing Ticketmaster posts with a better image/description --
    see tertiary_sources.py for why. An event from a tertiary source
    that doesn't match an existing post must never become its own
    standalone post; TM is always the authoritative listing for
    venues it serves.
    """
    if not source_name:
        return False
    with conn.cursor() as cur:
        cur.execute(
            f"SELECT 1 FROM {WP_PREFIX}openclaw_sources "
            f"WHERE name=%s AND tier='tertiary' LIMIT 1",
            (source_name,)
        )
        return cur.fetchone() is not None

'''

    # Insert the helper right before find_cross_source_match's definition
    anchor = "def find_cross_source_match(conn, event: dict, resolved_times: dict) -> int | None:"
    if anchor not in text:
        print("ERROR: could not find find_cross_source_match() in db.py — no changes made.")
        print("Apply the patch manually using db_patch_instructions.txt instead.")
        return
    text = text.replace(anchor, helper_fn.strip("\n") + "\n\n\n" + anchor, 1)

    # Insert the guard right after the cross_match_id block, before the
    # "Claim the fingerprint atomically" comment
    guard_anchor = "        # Claim the fingerprint atomically. Reserve post_id=0 as a"
    guard_code = (
        "        # cross_match_id was already checked and returned None above if we\n"
        "        # reach here. Before falling through to \"this is a brand new event,\n"
        "        # create a post for it,\" check whether this event came from a\n"
        "        # tertiary (info-only) source. If so, there's no TM post to enrich\n"
        "        # and this source should never publish its own standalone listing.\n"
        "        if _is_tertiary_source(conn, event.get(\"source_name\")):\n"
        "            log.info(\n"
        f"                \"{DB_GUARD_MARKER}: '%s' (%s)\",\n"
        "                event.get(\"title\"), event.get(\"source_name\")\n"
        "            )\n"
        "            conn.close()\n"
        "            return False\n\n"
    )

    if guard_anchor not in text:
        print("ERROR: could not find the fingerprint-claim section in db.py.")
        print("Helper function was added, but the guard was NOT inserted.")
        print("Apply the guard manually using db_patch_instructions.txt.")
        path.write_text(text)
        return

    text = text.replace(guard_anchor, guard_code + guard_anchor, 1)
    path.write_text(text)
    print("db.py patched successfully.")


def main():
    if not OPENCLAW_DIR.exists():
        print(f"ERROR: {OPENCLAW_DIR} not found. Run this on the server, not locally.")
        sys.exit(1)

    print("Patching ticketmaster.py...")
    patch_ticketmaster()
    print("Patching db.py...")
    patch_db()
    print("\nDone. Review the .bak files if you want to diff what changed:")
    print("  diff /opt/openclaw/ticketmaster.py.bak /opt/openclaw/ticketmaster.py")
    print("  diff /opt/openclaw/db.py.bak /opt/openclaw/db.py")


if __name__ == "__main__":
    main()
