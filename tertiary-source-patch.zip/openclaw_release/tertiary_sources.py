"""
tertiary_sources.py — auto-create tertiary (info-only) sources for
venues Ticketmaster surfaces that aren't yet in wp_openclaw_sources.

Called once per TM-pulled event, after _normalize() in ticketmaster.py.
Cheap no-op for the common case (venue already known) -- only does any
real work (fuzzy match miss -> Google Places lookup -> INSERT) the
first time a given venue shows up.

Why tertiary sources exist at all: Ticketmaster's own API frequently
has no usable image for smaller/regional listings (confirmed on
Exit/In's "LSD Clownsystem" show, 2026-06-29). Scraping the venue's
OWN site for the same event lets the existing cross-source merge
logic (db.find_cross_source_match + db._apply_image) backfill a
better image/description onto the TM-sourced post. Tertiary sources
are scraped on the normal schedule like any other source, but per the
insert_event() guard in db.py, a tertiary-sourced event that finds NO
matching TM post is discarded rather than becoming its own standalone
post -- TM is always the primary, authoritative listing for venues it
serves.
"""

import difflib
import logging

from config import _get_conn, WP_PREFIX
from places import find_venue_website

log = logging.getLogger("openclaw.tertiary_sources")

# Same threshold used elsewhere in db.py for cross-source title matching --
# kept consistent rather than inventing a new constant for venue names.
VENUE_SIMILARITY_THRESHOLD = 0.80


def ensure_tertiary_source(venue_name: str, venue_city_name: str, city_slug: str) -> None:
    """
    If `venue_name` doesn't fuzzy-match any existing source for this
    city, look up its website via Google Places and create a new
    probation-status, tertiary-tier source row.

    Never raises -- a failure here should never break a TM pull.
    """
    venue_name = (venue_name or "").strip()
    if not venue_name or not city_slug:
        return

    conn = _get_conn()
    try:
        if _matches_existing_source(conn, venue_name, city_slug):
            return

        website = find_venue_website(venue_name, venue_city_name)

        with conn.cursor() as cur:
            cur.execute(
                f"INSERT INTO {WP_PREFIX}openclaw_sources "
                f"(name, url, source_type, tier, status, city_slug, notes) "
                f"VALUES (%s, %s, %s, 'tertiary', 'probation', %s, %s)",
                (
                    venue_name,
                    website or "",
                    "html_auto",
                    city_slug,
                    "" if website else "Auto-created from Ticketmaster venue data — "
                                       "Google Places had no website on file. "
                                       "Needs a URL added manually before it can be fired.",
                )
            )
        conn.commit()
        log.info(
            "Auto-created tertiary source for venue '%s' (%s) — url=%s",
            venue_name, city_slug, website or "MISSING, needs manual entry"
        )
    except Exception as e:
        log.warning("Failed to auto-create tertiary source for '%s': %s", venue_name, e)
    finally:
        conn.close()


def _matches_existing_source(conn, venue_name: str, city_slug: str) -> bool:
    """
    Fuzzy-match venue_name against existing source names in the same
    city. Deliberately uses the same SequenceMatcher approach as
    db.find_cross_source_match() rather than an exact string match --
    TM's venue name and your source's display name often differ
    slightly (e.g. "The Exit/In" vs "Exit/In").
    """
    venue_norm = venue_name.strip().lower()

    with conn.cursor() as cur:
        cur.execute(
            f"SELECT name FROM {WP_PREFIX}openclaw_sources WHERE city_slug=%s",
            (city_slug,)
        )
        existing = cur.fetchall()

    for row in existing:
        existing_norm = (row["name"] or "").strip().lower()
        ratio = difflib.SequenceMatcher(None, venue_norm, existing_norm).ratio()
        if ratio >= VENUE_SIMILARITY_THRESHOLD:
            return True
    return False
