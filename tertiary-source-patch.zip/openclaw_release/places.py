"""
places.py — Google Places venue website lookup

Used when a Ticketmaster event references a venue that isn't yet a
known source in wp_openclaw_sources. TM's own API gives us the venue
name/address/lat-long but never an actual website -- its "url" field
is always a Ticketmaster affiliate redirect, not the venue's own site
(confirmed 2026-06-29 against Nissan Stadium's TM venue object).

Google Places' Find Place + Place Details chain reliably returns a
venue's real website for well-known/commercial venues, so we use it
to auto-resolve a scrapeable URL for new tertiary sources without any
manual lookup.

Two API calls per NEW venue only -- once a venue becomes a source row,
this never runs again for it. Cheap relative to TM's own per-city
pulls, and well within free-tier limits for a single city's worth of
venues.
"""

import logging

import requests

from config import GOOGLE_PLACES_API_KEY

log = logging.getLogger("openclaw.places")

FIND_PLACE_URL = "https://maps.googleapis.com/maps/api/place/findplacefromtext/json"
DETAILS_URL    = "https://maps.googleapis.com/maps/api/place/details/json"


def find_venue_website(venue_name: str, city: str) -> str | None:
    """
    Resolve a venue's real website via Google Places.

    Returns None (never raises) if the API key is missing, the venue
    can't be found, or the venue has no website on file -- all of
    these are expected, non-fatal outcomes for a best-effort lookup.
    """
    if not GOOGLE_PLACES_API_KEY:
        log.warning("GOOGLE_PLACES_API_KEY not set — skipping venue lookup for '%s'", venue_name)
        return None
    if not venue_name:
        return None

    place_id = _find_place_id(venue_name, city)
    if not place_id:
        log.info("No Google Places match for '%s' (%s)", venue_name, city)
        return None

    website = _get_website(place_id)
    if website:
        log.info("Resolved website for '%s': %s", venue_name, website)
    else:
        log.info("Google Places has no website on file for '%s'", venue_name)
    return website


def _find_place_id(venue_name: str, city: str) -> str | None:
    params = {
        "input":     f"{venue_name} {city}".strip(),
        "inputtype": "textquery",
        "fields":    "place_id",
        "key":       GOOGLE_PLACES_API_KEY,
    }
    try:
        resp = requests.get(FIND_PLACE_URL, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        log.warning("Google Places Find Place failed for '%s': %s", venue_name, e)
        return None

    if data.get("status") != "OK":
        # ZERO_RESULTS is expected/common, not an error worth a warning
        if data.get("status") not in ("ZERO_RESULTS",):
            log.warning("Google Places Find Place non-OK status for '%s': %s",
                        venue_name, data.get("status"))
        return None

    candidates = data.get("candidates", [])
    return candidates[0]["place_id"] if candidates else None


def _get_website(place_id: str) -> str | None:
    params = {
        "place_id": place_id,
        "fields":   "website",
        "key":      GOOGLE_PLACES_API_KEY,
    }
    try:
        resp = requests.get(DETAILS_URL, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        log.warning("Google Places Details failed for place_id '%s': %s", place_id, e)
        return None

    if data.get("status") != "OK":
        log.warning("Google Places Details non-OK status for place_id '%s': %s",
                    place_id, data.get("status"))
        return None

    return (data.get("result") or {}).get("website") or None
