"""
add_tier_column.py — one-time migration: add `tier` to wp_openclaw_sources

Tiers:
  primary   — Ticketmaster itself (the API pull, not a row in this table)
  secondary — independent venues you actively scrape for full listings
              (this is what every existing source effectively is today)
  tertiary  — venues served by Ticketmaster (or another listing agency
              you don't have an affiliate deal with). Scraped on the
              normal schedule for enrichment (image/description) ONLY.
              Their events must never become standalone posts — see
              the insert_event() guard in db.py.

Existing rows all default to 'secondary' since that's what they
currently behave as. Safe to run multiple times (idempotent).

Usage:
  /opt/openclaw/venv/bin/python /opt/openclaw/add_tier_column.py
"""

import sys
sys.path.insert(0, "/opt/openclaw")

from config import _get_conn, WP_PREFIX


def column_exists(conn, table, column) -> bool:
    with conn.cursor() as cur:
        cur.execute(
            "SELECT COUNT(*) AS c FROM information_schema.COLUMNS "
            "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s",
            (table, column)
        )
        row = cur.fetchone()
        return bool(row and row["c"] > 0)


def main():
    conn = _get_conn()
    try:
        table = f"{WP_PREFIX}openclaw_sources"

        if column_exists(conn, table, "tier"):
            print(f"Column 'tier' already exists on {table} — nothing to do.")
            return

        with conn.cursor() as cur:
            cur.execute(
                f"ALTER TABLE {table} "
                f"ADD COLUMN tier ENUM('primary','secondary','tertiary') "
                f"NOT NULL DEFAULT 'secondary' AFTER source_type"
            )
        conn.commit()
        print(f"Added 'tier' column to {table}, all existing rows defaulted to 'secondary'.")

        with conn.cursor() as cur:
            cur.execute(f"SELECT tier, COUNT(*) AS n FROM {table} GROUP BY tier")
            for row in cur.fetchall():
                print(f"  {row['tier']}: {row['n']} sources")
    finally:
        conn.close()


if __name__ == "__main__":
    main()
