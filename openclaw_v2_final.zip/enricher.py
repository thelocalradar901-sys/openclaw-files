"""
enricher.py — Ollama AI description enricher
Only runs on events with _needs_enrichment=True and no description.
"""

import logging
import re

import requests

from config import OLLAMA_HOST, OLLAMA_MODEL, OLLAMA_TIMEOUT

log = logging.getLogger("openclaw.enricher")


def enrich_events(events: list[dict]) -> list[dict]:
    needs = [e for e in events if e.get("_needs_enrichment") and not e.get("description")]
    if not needs:
        return events
    log.info("Enriching %d events via Ollama", len(needs))
    for event in needs:
        desc = _generate(event)
        if desc:
            event["description"]       = desc
            event["_needs_enrichment"] = False
    return events


def _generate(event: dict) -> str:
    parts = [f"Event: {event.get('title', '')}"]
    if event.get("venue_name"):  parts.append(f"Venue: {event['venue_name']}")
    if event.get("city_slug"):   parts.append(f"City: {event['city_slug'].replace('-',' ').title()}")
    if event.get("cost"):        parts.append(f"Price: {event['cost']}")
    cats = ", ".join(event.get("categories") or [])
    if cats:                     parts.append(f"Type: {cats}")

    prompt = (
        "Write a concise, engaging 2-3 sentence event description for a local events website. "
        "Energetic local voice. Don't include the date, price, or 'Join us'. "
        "Return only the description text.\n\n" + "\n".join(parts)
    )
    try:
        resp = requests.post(
            f"{OLLAMA_HOST}/api/generate",
            json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
            timeout=OLLAMA_TIMEOUT,
        )
        resp.raise_for_status()
        text = resp.json().get("response", "").strip()
        return re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
    except Exception as e:
        log.warning("Enrichment failed for '%s': %s", event.get("title"), e)
        return ""
