"""
scheduler.py — APScheduler job coordinator

Jobs:
  - Ticketmaster: one per city, every TICKETMASTER_INTERVAL seconds (default 1h)
  - Scraper:      one per source, every SCRAPER_INTERVAL seconds (default 2h)
  - DB refresh:   every hour — picks up new cities/sources without daemon restart

All jobs run immediately on startup, then on their interval.
"""

import logging
from datetime import datetime, timezone

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger

from config import (
    TICKETMASTER_INTERVAL, SCRAPER_INTERVAL,
    load_cities, load_dynamic_sources, update_source_stats,
)

log = logging.getLogger("openclaw.scheduler")

_cities  = []
_sources = {}


def start_scheduler() -> BackgroundScheduler:
    global _cities, _sources
    _cities  = load_cities()
    _sources = load_dynamic_sources()

    scheduler = BackgroundScheduler(timezone="UTC")

    # Ticketmaster jobs
    for city in _cities:
        scheduler.add_job(
            _run_ticketmaster,
            trigger=IntervalTrigger(seconds=TICKETMASTER_INTERVAL),
            args=[city],
            id=f"tm_{city['slug']}",
            name=f"Ticketmaster – {city['name']}",
            replace_existing=True,
            max_instances=1,
        )

    # Scraper jobs
    for city_slug, sources in _sources.items():
        for source in sources:
            jid = f"scraper_{city_slug}_{source['_db_id']}"
            scheduler.add_job(
                _run_scraper,
                trigger=IntervalTrigger(seconds=SCRAPER_INTERVAL),
                args=[source, _city_dict(city_slug)],
                id=jid,
                name=f"{source['name']} / {city_slug}",
                replace_existing=True,
                max_instances=1,
            )

    # DB refresh
    scheduler.add_job(
        _refresh,
        trigger=IntervalTrigger(seconds=3600),
        args=[scheduler],
        id="db_refresh",
        name="Refresh cities + sources",
        replace_existing=True,
    )

    scheduler.start()

    # Fire everything immediately
    _fire_all(scheduler)

    log.info("Scheduler started — %d cities, %d sources",
             len(_cities), sum(len(v) for v in _sources.values()))
    return scheduler


def _fire_all(scheduler: BackgroundScheduler):
    now = datetime.now(timezone.utc)
    for job in scheduler.get_jobs():
        if job.id != "db_refresh":
            try:
                job.modify(next_run_time=now)
            except Exception:
                pass


def _run_ticketmaster(city: dict):
    from ticketmaster import pull_city
    from db import insert_event
    try:
        events   = pull_city(city)
        inserted = skipped = 0
        for ev in events:
            if insert_event(ev, city):
                inserted += 1
            else:
                skipped += 1
        log.info("TM %s: %d inserted, %d skipped", city["name"], inserted, skipped)
    except Exception as e:
        log.error("TM job failed for %s: %s", city["name"], e, exc_info=True)


def _run_scraper(source: dict, city: dict):
    from scraper import scrape_source
    from enricher import enrich_events
    from db import insert_event
    try:
        events   = scrape_source(source, city)
        events   = enrich_events(events)
        inserted = skipped = 0
        for ev in events:
            if insert_event(ev, city):
                inserted += 1
            else:
                skipped += 1
        log.info("Scraper '%s' %s: %d inserted, %d skipped",
                 source["name"], city["name"], inserted, skipped)
        if source.get("_db_id"):
            update_source_stats(source["_db_id"], inserted)
    except Exception as e:
        log.error("Scraper failed %s/%s: %s",
                  source.get("name"), city.get("name"), e, exc_info=True)


def _refresh(scheduler: BackgroundScheduler):
    global _cities, _sources
    log.info("Refreshing cities and sources from DB")
    try:
        new_cities  = load_cities()
        new_sources = load_dynamic_sources()
    except Exception as e:
        log.error("Refresh failed: %s", e)
        return

    _cities  = new_cities
    _sources = new_sources

    now = datetime.now(timezone.utc)

    for city in _cities:
        jid = f"tm_{city['slug']}"
        if not scheduler.get_job(jid):
            scheduler.add_job(
                _run_ticketmaster,
                trigger=IntervalTrigger(seconds=TICKETMASTER_INTERVAL),
                args=[city], id=jid,
                name=f"Ticketmaster – {city['name']}",
                replace_existing=True, max_instances=1,
            )
            scheduler.get_job(jid).modify(next_run_time=now)
            log.info("Added TM job for new city: %s", city["name"])

    for city_slug, sources in _sources.items():
        for source in sources:
            jid = f"scraper_{city_slug}_{source['_db_id']}"
            if not scheduler.get_job(jid):
                scheduler.add_job(
                    _run_scraper,
                    trigger=IntervalTrigger(seconds=SCRAPER_INTERVAL),
                    args=[source, _city_dict(city_slug)],
                    id=jid, name=f"{source['name']} / {city_slug}",
                    replace_existing=True, max_instances=1,
                )
                scheduler.get_job(jid).modify(next_run_time=now)
                log.info("Added scraper job: %s / %s", source["name"], city_slug)

    log.info("Refresh done — %d cities, %d sources",
             len(_cities), sum(len(v) for v in _sources.values()))


def _city_dict(slug: str) -> dict:
    for c in _cities:
        if c["slug"] == slug:
            return c
    return {"slug": slug, "name": slug.title(), "lat": 0, "lng": 0, "timezone": "America/Chicago"}
