"""
config.py — OpenClaw runtime configuration
Cities and sources loaded from DB. Static CITIES is emergency fallback only.
"""

import logging
import os

import pymysql
import pymysql.cursors

log = logging.getLogger("openclaw.config")

LOG_LEVEL = os.getenv("OPENCLAW_LOG_LEVEL", "INFO")

DB = {
    "host":     os.getenv("WP_DB_HOST",     "localhost"),
    "port":     int(os.getenv("WP_DB_PORT", 3306)),
    "user":     os.getenv("WP_DB_USER",     "wpuser"),
    "password": os.getenv("WP_DB_PASSWORD", ""),
    "database": os.getenv("WP_DB_NAME",     "wordpress"),
    "charset":  "utf8mb4",
}

WP_PREFIX = os.getenv("WP_PREFIX", "wp_")

# Ticketmaster — API key from env, affiliate ID hardcoded
TICKETMASTER_API_KEY = os.getenv("TICKETMASTER_API_KEY", "")
TM_AFFILIATE_ID      = "7097599"
TM_RADIUS            = "50"
TM_UNIT              = "miles"
TM_SIZE              = 200
TM_SEGMENTS          = ["Music", "Arts & Theatre", "Sports", "Family", "Miscellaneous"]

# Ollama
OLLAMA_HOST    = os.getenv("OLLAMA_HOST",    "http://localhost:11434")
OLLAMA_MODEL   = os.getenv("OLLAMA_MODEL",   "qwen3:14b")
OLLAMA_TIMEOUT = int(os.getenv("OLLAMA_TIMEOUT", 60))

# Scheduler
TICKETMASTER_INTERVAL = int(os.getenv("TM_INTERVAL",      3600))
SCRAPER_INTERVAL      = int(os.getenv("SCRAPER_INTERVAL", 7200))

# Images
SIDELOAD_IMAGES = True
IMAGE_TIMEOUT   = 15

# Static fallback cities (only used if DB is unreachable)
CITIES = [
    {"name": "Memphis",    "slug": "memphis",    "ticketmaster_dma_id": "322",
     "lat": 35.1495,  "lng": -90.0490,  "radius_miles": 35, "timezone": "America/Chicago"},
    {"name": "Denver",     "slug": "denver",     "ticketmaster_dma_id": "302",
     "lat": 39.7392,  "lng": -104.9903, "radius_miles": 35, "timezone": "America/Denver"},
    {"name": "Nashville",  "slug": "nashville",  "ticketmaster_dma_id": "324",
     "lat": 36.1627,  "lng": -86.7816,  "radius_miles": 35, "timezone": "America/Chicago"},
    {"name": "Birmingham", "slug": "birmingham", "ticketmaster_dma_id": "630",
     "lat": 33.5186,  "lng": -86.8104,  "radius_miles": 35, "timezone": "America/Chicago"},
]

# ── TLR Categories ────────────────────────────────────────────────────────────
# Exactly 7 slugs. Order matters — first keyword match wins per category.
# more-to-do has no keywords; it's the catch-all fallback.
TLR_CATEGORIES = [
    ("live-music-concerts", [
        "concert", "live music", "live band", "dj set", "dj night",
        "jazz", "blues", "hip hop", "hip-hop", "country music",
        "rock show", "indie", "rap", "r&b", "soul", "folk",
        "metal", "punk", "singer songwriter", "open jam",
        "open mic night", "open mic",
    ]),
    ("comedy", [
        "comedy show", "comedy night", "stand-up", "standup",
        "stand up comedy", "improv", "comedian", "laughs",
    ]),
    ("performing-visual-arts", [
        "theater", "theatre", "ballet", "opera", "symphony",
        "orchestra", "dance performance", "gallery opening",
        "art exhibit", "museum exhibit", "film screening",
        "art show", "art walk", "drag show", "burlesque",
        "magic show", "spoken word", "poetry reading",
    ]),
    ("sports-fitness", [
        # pro/college sports
        "grizzlies", "hustle", "tigers", "nba", "nfl", "mlb", "nhl", "mls",
        "soccer game", "football game", "basketball game", "baseball game",
        "hockey game", "playoff", "championship game",
        # running/racing
        "5k", "10k", "marathon", "half marathon", "fun run", "trot",
        # fitness classes
        "yoga", "pilates", "zumba", "barre", "spin class",
        "cycling class", "boot camp", "bootcamp", "crossfit",
        "fitness class", "workout", "wellness series",
        # outdoor/sport
        "swim meet", "triathlon", "bike ride", "tennis", "golf tournament",
        "pickleball", "volleyball tournament",
    ]),
    ("festivals", [
        "festival", "street fair", "street fest", "block party",
        "outdoor fair", "carnival", "flea market", "holiday market",
        "pride festival", "oktoberfest", "mardi gras",
    ]),
    ("family-community", [
        "family friendly", "kids event", "children", "youth",
        "storytime", "all ages", "toddler", "baby",
        "community event", "neighborhood", "volunteer",
        "charity event", "fundraiser", "civic",
    ]),
    ("more-to-do", []),  # catch-all, always last
]

# TM classification names → TLR slugs
TM_TO_TLR = {
    # segments
    "music":          "live-music-concerts",
    "arts & theatre": "performing-visual-arts",
    "sports":         "sports-fitness",
    "family":         "family-community",
    "miscellaneous":  "more-to-do",
    # genres
    "comedy":         "comedy",
    "classical":      "performing-visual-arts",
    "theatre":        "performing-visual-arts",
    "dance":          "performing-visual-arts",
    "film":           "performing-visual-arts",
    "jazz":           "live-music-concerts",
    "blues":          "live-music-concerts",
    "r&b":            "live-music-concerts",
    "hip-hop/rap":    "live-music-concerts",
    "rock":           "live-music-concerts",
    "pop":            "live-music-concerts",
    "country":        "live-music-concerts",
    "folk":           "live-music-concerts",
    "metal":          "live-music-concerts",
    "alternative":    "live-music-concerts",
    "reggae":         "live-music-concerts",
    "latin":          "live-music-concerts",
    "gospel":         "live-music-concerts",
    "dance/electronic": "live-music-concerts",
}


# ── DB helpers ────────────────────────────────────────────────────────────────

def _get_conn():
    return pymysql.connect(
        host=DB["host"], port=DB["port"], user=DB["user"],
        password=DB["password"], database=DB["database"],
        charset=DB["charset"], cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )


def load_cities() -> list[dict]:
    """Load active cities from wp_openclaw_cities. Falls back to static CITIES."""
    try:
        conn = _get_conn()
        with conn.cursor() as cur:
            cur.execute("""
                SELECT name, slug, tm_dma_id, lat, lng, radius_miles
                FROM wp_openclaw_cities
                WHERE status = 'active'
                ORDER BY name
            """)
            rows = cur.fetchall()
        conn.close()

        if not rows:
            log.warning("No active cities in DB — using static fallback")
            return CITIES

        result = []
        for row in rows:
            slug = row["slug"]
            result.append({
                "name":                row["name"],
                "slug":                slug,
                "ticketmaster_dma_id": row["tm_dma_id"] or "",
                "lat":                 float(row["lat"]          or 0),
                "lng":                 float(row["lng"]          or 0),
                "radius_miles":        int(row["radius_miles"]   or 35),
                # Timezone: look up from static list, default Chicago
                "timezone": next(
                    (c["timezone"] for c in CITIES if c["slug"] == slug),
                    "America/Chicago"
                ),
            })
        log.info("Loaded %d cities from DB", len(result))
        return result

    except Exception as e:
        log.error("Failed to load cities: %s — using static fallback", e)
        return CITIES


def load_dynamic_sources() -> dict:
    """
    Load active scrape sources from wp_openclaw_sources grouped by city_slug.
    Returns { "memphis": [source_dict, ...], ... }
    """
    import json as _json
    cities  = load_cities()
    by_city = {c["slug"]: [] for c in cities}

    try:
        conn = _get_conn()
        with conn.cursor() as cur:
            cur.execute("""
                SELECT id, url, city_slug, name, source_type, notes
                FROM wp_openclaw_sources
                WHERE status = 'active'
                ORDER BY city_slug, id
            """)
            rows = cur.fetchall()
        conn.close()

        for row in rows:
            slug = row["city_slug"]
            if slug not in by_city:
                by_city[slug] = []

            extra = {}
            try:
                if row.get("notes"):
                    extra = _json.loads(row["notes"])
            except Exception:
                pass

            stype = (row["source_type"] or "html_auto").strip()
            if stype in ("auto", "squarespace"):
                stype = "html_auto"

            by_city[slug].append({
                "_db_id":      row["id"],
                "name":        row["name"] or row["url"],
                "url":         row["url"],
                "source_type": stype,
                "city_slug":   slug,
                **extra,
            })

        total = sum(len(v) for v in by_city.values())
        log.info("Loaded %d sources from DB", total)

    except Exception as e:
        log.error("Failed to load sources: %s", e)

    return by_city


def update_source_stats(db_id: int, count: int):
    """Update last_run and last_count for a scrape source."""
    try:
        conn = _get_conn()
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE wp_openclaw_sources SET last_run=NOW(), last_count=%s WHERE id=%s",
                (count, db_id)
            )
        conn.commit()
        conn.close()
    except Exception as e:
        log.error("Failed to update source stats id=%s: %s", db_id, e)
