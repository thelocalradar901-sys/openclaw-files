#!/usr/bin/env python3
"""
openclaw.py — OpenClaw event aggregation daemon
Runs as a systemd service.
"""

import logging
import os
import signal
import sys
import time

from config import LOG_LEVEL

os.makedirs("/var/log/openclaw", exist_ok=True)

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(asctime)s,%(msecs)03d [%(levelname)s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("/var/log/openclaw/openclaw.log"),
    ],
)
log = logging.getLogger("openclaw")


def shutdown(signum, frame):
    log.info("Shutdown signal %d received", signum)
    sys.exit(0)


def main():
    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGINT,  shutdown)

    log.info("OpenClaw starting")

    from scheduler import start_scheduler
    scheduler = start_scheduler()

    try:
        while True:
            time.sleep(30)
    except (KeyboardInterrupt, SystemExit):
        scheduler.shutdown(wait=False)
        log.info("OpenClaw stopped")


if __name__ == "__main__":
    main()
