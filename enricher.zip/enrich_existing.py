"""
enrich_existing.py — One-time backfill script to generate descriptions
for existing TM events that have no description.
Run: sudo /opt/openclaw/venv/bin/python /tmp/enrich_existing.py
"""

import logging
import re
import sys
import requests
import pymysql
import pymysql.cursors

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
log = logging.getLogger("enrich_backfill")

DB = dict(host="localhost", user="wpuser", password="wpDB_pass789",
          database="wordpress", charset="utf8mb4",
          cursorclass=pymysql.cursors.DictCursor)

OLLAMA_HOST    = "http://localhost:11434"
OLLAMA_MODEL   = "qwen3:14b"
OLLAMA_TIMEOUT = 120


def get_events_needing_description(conn):
    with conn.cursor() as cur:
        cur.execute("""
            SELECT p.ID, p.post_title,
                   MAX(CASE WHEN pm.meta_key='_EventURL'      THEN pm.meta_value END) as ticket_url,
                   MAX(CASE WHEN pm.meta_key='_EventCost'     THEN pm.meta_value END) as cost,
                   MAX(CASE WHEN pm.meta_key='_EventStartDate' THEN pm.meta_value END) as start_date,
                   MAX(CASE WHEN pm.meta_key='_openclaw_city' THEN pm.meta_value END) as city_slug,
                   MAX(CASE WHEN pm.meta_key='_openclaw_source' THEN pm.meta_value END) as source
            FROM wp_posts p
            JOIN wp_postmeta pm ON p.ID = pm.post_id
            WHERE p.post_type = 'tribe_events'
            AND p.post_status = 'publish'
            AND (p.post_content = '' OR p.post_content IS NULL)
            GROUP BY p.ID, p.post_title
            LIMIT 500
        """)
        return cur.fetchall()


def get_venue(conn, post_id):
    with conn.cursor() as cur:
        cur.execute("""
            SELECT pm2.meta_value as venue_name
            FROM wp_postmeta pm1
            JOIN wp_posts v ON pm1.meta_value = v.ID
            JOIN wp_postmeta pm2 ON v.ID = pm2.post_id AND pm2.meta_key = '_VenueName'
            WHERE pm1.post_id = %s AND pm1.meta_key = '_EventVenueID'
            LIMIT 1
        """, (post_id,))
        row = cur.fetchone()
        return row["venue_name"] if row else ""


def generate_description(title, venue, city, start_date, cost, source):
    title_lower = title.lower()
    is_sports = any(k in title_lower for k in [
        " vs ", " vs. ", "game", "match", "fc", "legion", "barons",
        "redbirds", "grizzlies", "hustle", "tigers", "nba", "nfl", "mlb", "nhl", "mls"
    ])
    is_concert = any(k in title_lower for k in [
        "tour", "live", "concert", "presents", "performing"
    ]) and not is_sports

    lines = [f"Event: {title}"]
    if venue:      lines.append(f"Venue: {venue}")
    if city:       lines.append(f"City: {city.replace('-',' ').title()}")
    if start_date: lines.append(f"Date: {start_date[:10]}")
    if cost:       lines.append(f"Price: {cost}")

    if is_sports:
        lines.append("Note: Use your knowledge of these teams to write an exciting match preview.")
    elif is_concert:
        lines.append("Note: Use your knowledge of this artist to write an engaging description.")

    context = "\n".join(lines)
    prompt = (
        "You are a writer for a local events website with an energetic, local voice.\n"
        "Write a 2-3 sentence event description based on the details below.\n"
        "Do NOT include the date, price, or start with 'Join us'.\n"
        "Use your knowledge of the artist or team if you recognize them.\n"
        "Return ONLY the description text.\n\n"
        f"{context}"
    )

    try:
        resp = requests.post(
            f"{OLLAMA_HOST}/api/generate",
            json={"model": OLLAMA_MODEL, "prompt": prompt, "stream": False},
            timeout=OLLAMA_TIMEOUT,
        )
        resp.raise_for_status()
        text = resp.json().get("response", "").strip()
        text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL).strip()
        return text.strip('"\'')
    except Exception as e:
        log.warning("Ollama failed for '%s': %s", title, e)
        return ""


def main():
    conn = pymysql.connect(**DB)
    events = get_events_needing_description(conn)
    log.info("Found %d events needing descriptions", len(events))

    updated = 0
    for i, event in enumerate(events):
        post_id = event["ID"]
        title   = event["post_title"]
        venue   = get_venue(conn, post_id)

        desc = generate_description(
            title=title,
            venue=venue,
            city=event.get("city_slug") or "",
            start_date=event.get("start_date") or "",
            cost=event.get("cost") or "",
            source=event.get("source") or "",
        )

        if desc:
            with conn.cursor() as cur:
                cur.execute(
                    "UPDATE wp_posts SET post_content=%s WHERE ID=%s",
                    (desc, post_id)
                )
                cur.execute(
                    "UPDATE wp_postmeta SET meta_value=%s WHERE post_id=%s AND meta_key='_EventDescription'",
                    (desc, post_id)
                )
                cur.execute(
                    "INSERT IGNORE INTO wp_postmeta (post_id, meta_key, meta_value) VALUES (%s,'_EventDescription',%s)",
                    (post_id, desc)
                )
            conn.commit()
            updated += 1
            log.info("[%d/%d] %s", i+1, len(events), title[:60])
        else:
            log.warning("No description generated for: %s", title)

    conn.close()
    log.info("Done — enriched %d events", updated)


if __name__ == "__main__":
    main()
