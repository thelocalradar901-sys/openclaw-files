"""
scraper_auto.py — Universal HTML scraper for OpenClaw.

Tiered extraction strategy per source:
  1. iCal feed detection  → parse with icalendar
  2. TEC/JSON-LD detection → structured event extraction
  3. Heuristic HTML parser → BeautifulSoup pattern matching
  4. Qwen3 AI fallback     → raw HTML chunk sent to Ollama

Returns a list of normalized event dicts compatible with db.py write layer.
"""

import re
import json
import hashlib
import logging
import requests
from datetime import datetime, timezone
from typing import Optional
from bs4 import BeautifulSoup
import ollama  # ollama-python client

logger = logging.getLogger("openclaw.scraper_auto")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
}

REQUEST_TIMEOUT = 20  # seconds

# Max chars of HTML sent to Qwen3 to stay under context limits
AI_HTML_CHAR_LIMIT = 12_000

QWEN_MODEL = "qwen3:14b"

# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def scrape_source(source: dict) -> list[dict]:
    """
    Main entry point. Accepts a source dict from sources.json, returns a
    list of normalized event dicts (empty list on full failure).
    """
    url = source.get("url", "")
    name = source.get("name", url)
    city = source.get("city", "unknown")

    logger.info(f"[{name}] Fetching {url}")

    try:
        resp = requests.get(url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
    except Exception as exc:
        logger.error(f"[{name}] HTTP error: {exc}")
        return []

    html = resp.text

    # --- Tier 1: iCal ---
    ical_url = _detect_ical(html, url)
    if ical_url:
        events = _parse_ical(ical_url, city, name)
        if events:
            logger.info(f"[{name}] iCal tier: {len(events)} events")
            return events

    # --- Tier 2: JSON-LD / TEC REST ---
    events = _parse_jsonld(html, city, name)
    if events:
        logger.info(f"[{name}] JSON-LD tier: {len(events)} events")
        return events

    # --- Tier 3: Heuristic HTML ---
    events = _parse_heuristic(html, url, city, name)
    if events:
        logger.info(f"[{name}] Heuristic tier: {len(events)} events")
        return events

    # --- Tier 4: Qwen3 AI fallback ---
    logger.info(f"[{name}] Falling back to Qwen3 AI extraction")
    events = _parse_ai(html, url, city, name)
    if events:
        logger.info(f"[{name}] AI tier: {len(events)} events")
    else:
        logger.warning(f"[{name}] All tiers failed — no events extracted")

    return events


# ---------------------------------------------------------------------------
# Tier 1: iCal
# ---------------------------------------------------------------------------

def _detect_ical(html: str, base_url: str) -> Optional[str]:
    """Look for .ics links or feed links in HTML."""
    soup = BeautifulSoup(html, "html.parser")

    # <link rel="alternate" type="text/calendar"> pattern (TEC standard)
    tag = soup.find("link", {"type": "text/calendar"})
    if tag and tag.get("href"):
        href = tag["href"]
        return href if href.startswith("http") else _abs(href, base_url)

    # Inline .ics href
    for a in soup.find_all("a", href=True):
        if ".ics" in a["href"]:
            href = a["href"]
            return href if href.startswith("http") else _abs(href, base_url)

    return None


def _parse_ical(ical_url: str, city: str, source_name: str) -> list[dict]:
    try:
        from icalendar import Calendar
        resp = requests.get(ical_url, headers=HEADERS, timeout=REQUEST_TIMEOUT)
        resp.raise_for_status()
        cal = Calendar.from_ical(resp.content)
        events = []
        for component in cal.walk():
            if component.name != "VEVENT":
                continue
            title = str(component.get("SUMMARY", "")).strip()
            dtstart = component.get("DTSTART")
            dtend = component.get("DTEND")
            if not title or not dtstart:
                continue
            start_dt = _to_datetime(dtstart.dt)
            end_dt = _to_datetime(dtend.dt) if dtend else None
            desc = str(component.get("DESCRIPTION", "")).strip()
            event_url = str(component.get("URL", "")).strip()
            venue = str(component.get("LOCATION", source_name)).strip()
            events.append(_normalize(
                title=title,
                start=start_dt,
                end=end_dt,
                description=desc,
                url=event_url,
                venue=venue,
                city=city,
                source=source_name,
            ))
        return events
    except Exception as exc:
        logger.warning(f"iCal parse failed for {ical_url}: {exc}")
        return []


# ---------------------------------------------------------------------------
# Tier 2: JSON-LD
# ---------------------------------------------------------------------------

def _parse_jsonld(html: str, city: str, source_name: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    events = []

    for script in soup.find_all("script", {"type": "application/ld+json"}):
        try:
            data = json.loads(script.string or "")
        except Exception:
            continue

        # Unwrap @graph if present
        items = data if isinstance(data, list) else [data]
        if isinstance(data, dict) and "@graph" in data:
            items = data["@graph"]

        for item in items:
            if not isinstance(item, dict):
                continue
            etype = item.get("@type", "")
            # Accept Event, MusicEvent, SocialEvent, etc.
            if "Event" not in etype:
                continue

            title = item.get("name", "").strip()
            start_raw = item.get("startDate", "")
            end_raw = item.get("endDate", "")
            desc = item.get("description", "").strip()
            url = item.get("url", "").strip()

            # Venue
            location = item.get("location", {})
            if isinstance(location, dict):
                venue = location.get("name", source_name)
            else:
                venue = str(location) or source_name

            if not title or not start_raw:
                continue

            start_dt = _parse_iso(start_raw)
            end_dt = _parse_iso(end_raw) if end_raw else None
            if not start_dt:
                continue

            events.append(_normalize(
                title=title,
                start=start_dt,
                end=end_dt,
                description=desc,
                url=url,
                venue=venue,
                city=city,
                source=source_name,
            ))

    return events


# ---------------------------------------------------------------------------
# Tier 3: Heuristic HTML
# ---------------------------------------------------------------------------

# Common CSS class/attribute fragments that event containers use
_EVENT_SELECTORS = [
    "[class*='event-item']",
    "[class*='event_item']",
    "[class*='eventCard']",
    "[class*='event-card']",
    "[class*='event-list-item']",
    "[class*='tribe-event']",
    "[class*='tribe_event']",
    "article[class*='event']",
    "li[class*='event']",
    ".vevent",
]

_TITLE_SELECTORS = [
    "h1", "h2", "h3",
    "[class*='event-title']",
    "[class*='event_title']",
    "[class*='tribe-event-title']",
    ".summary",
]

_DATE_SELECTORS = [
    "time",
    "[class*='date']",
    "[class*='tribe-event-date']",
    "[class*='event-date']",
    ".dtstart",
]

_URL_SELECTORS = ["a[href]"]


def _parse_heuristic(html: str, base_url: str, city: str, source_name: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    containers = []

    for sel in _EVENT_SELECTORS:
        found = soup.select(sel)
        if found:
            containers = found
            break

    if not containers:
        return []

    events = []
    for container in containers[:50]:  # cap at 50 per page
        title = _first_text(container, _TITLE_SELECTORS)
        if not title:
            continue

        # Date: prefer datetime attr, fallback to text
        date_tag = _first_tag(container, _DATE_SELECTORS)
        date_str = ""
        if date_tag:
            date_str = date_tag.get("datetime", "") or date_tag.get_text(strip=True)

        start_dt = _parse_flexible_date(date_str)
        if not start_dt:
            continue

        # URL
        a_tag = container.find("a", href=True)
        event_url = ""
        if a_tag:
            href = a_tag["href"]
            event_url = href if href.startswith("http") else _abs(href, base_url)

        # Description: any <p> inside the container
        p_tag = container.find("p")
        desc = p_tag.get_text(strip=True) if p_tag else ""

        events.append(_normalize(
            title=title,
            start=start_dt,
            end=None,
            description=desc,
            url=event_url,
            venue=source_name,
            city=city,
            source=source_name,
        ))

    return events


# ---------------------------------------------------------------------------
# Tier 4: Qwen3 AI fallback
# ---------------------------------------------------------------------------

_AI_SYSTEM_PROMPT = """You are an event data extraction assistant.
Given HTML from an events page, extract all events and return ONLY valid JSON — 
no preamble, no markdown fences, no explanation.

Return a JSON array of objects with these keys:
  title       (string, required)
  start_date  (string, ISO 8601 or "YYYY-MM-DD HH:MM", required)
  end_date    (string, ISO 8601 or "YYYY-MM-DD HH:MM", optional)
  description (string, optional)
  url         (string, optional — full URL if available)
  venue       (string, optional)

If no events are found, return an empty array: []
"""


def _parse_ai(html: str, base_url: str, city: str, source_name: str) -> list[dict]:
    # Strip scripts/styles and truncate
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "noscript", "svg", "img"]):
        tag.decompose()
    clean_html = soup.get_text(separator="\n", strip=True)[:AI_HTML_CHAR_LIMIT]

    prompt = f"Source: {source_name} ({base_url})\n\nPage content:\n{clean_html}"

    try:
        response = ollama.chat(
            model=QWEN_MODEL,
            messages=[
                {"role": "system", "content": _AI_SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            options={"temperature": 0},
        )
        raw = response["message"]["content"].strip()

        # Strip any accidental markdown fences
        raw = re.sub(r"^```[a-z]*\n?", "", raw)
        raw = re.sub(r"\n?```$", "", raw)

        items = json.loads(raw)
        if not isinstance(items, list):
            return []

        events = []
        for item in items:
            title = item.get("title", "").strip()
            start_raw = item.get("start_date", "")
            if not title or not start_raw:
                continue
            start_dt = _parse_flexible_date(start_raw) or _parse_iso(start_raw)
            if not start_dt:
                continue
            end_raw = item.get("end_date", "")
            end_dt = _parse_flexible_date(end_raw) or _parse_iso(end_raw) if end_raw else None
            events.append(_normalize(
                title=title,
                start=start_dt,
                end=end_dt,
                description=item.get("description", ""),
                url=item.get("url", ""),
                venue=item.get("venue", source_name),
                city=city,
                source=source_name,
            ))
        return events

    except json.JSONDecodeError as exc:
        logger.error(f"[{source_name}] AI tier JSON parse error: {exc}")
        return []
    except Exception as exc:
        logger.error(f"[{source_name}] AI tier error: {exc}")
        return []


# ---------------------------------------------------------------------------
# Normalization
# ---------------------------------------------------------------------------

def _normalize(
    title: str,
    start: datetime,
    end: Optional[datetime],
    description: str,
    url: str,
    venue: str,
    city: str,
    source: str,
) -> dict:
    """Return a canonical event dict for db.py consumption."""
    fingerprint = hashlib.sha256(
        f"{title.lower().strip()}|{start.date().isoformat()}|{city}".encode()
    ).hexdigest()

    return {
        "title": title,
        "start_date": start.strftime("%Y-%m-%d"),
        "start_time": start.strftime("%H:%M:%S") if start.hour or start.minute else None,
        "end_date": end.strftime("%Y-%m-%d") if end else None,
        "end_time": end.strftime("%H:%M:%S") if end else None,
        "description": description or "",
        "url": url or "",
        "venue": venue or "",
        "city": city,
        "source": source,
        "fingerprint": fingerprint,
    }


# ---------------------------------------------------------------------------
# Date parsing helpers
# ---------------------------------------------------------------------------

def _parse_iso(s: str) -> Optional[datetime]:
    if not s:
        return None
    for fmt in (
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%dT%H:%M%z",
        "%Y-%m-%dT%H:%M",
        "%Y-%m-%d",
    ):
        try:
            dt = datetime.strptime(s[:19], fmt[:len(fmt)])
            return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
        except ValueError:
            continue
    return None


def _parse_flexible_date(s: str) -> Optional[datetime]:
    """Best-effort parse for human-readable and ISO date strings."""
    if not s:
        return None
    s = s.strip()

    # Try ISO first
    iso = _parse_iso(s)
    if iso:
        return iso

    # Common human formats
    for fmt in (
        "%B %d, %Y %I:%M %p",
        "%B %d, %Y %I %p",
        "%B %d, %Y",
        "%b %d, %Y %I:%M %p",
        "%b %d, %Y",
        "%m/%d/%Y %I:%M %p",
        "%m/%d/%Y",
        "%A, %B %d, %Y",
        "%A, %b %d, %Y",
    ):
        try:
            return datetime.strptime(s, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue

    # Strip trailing timezone abbreviations like "CDT", "EST" and retry
    cleaned = re.sub(r"\s+[A-Z]{2,5}$", "", s).strip()
    if cleaned != s:
        return _parse_flexible_date(cleaned)

    return None


def _to_datetime(dt_val) -> datetime:
    """Convert icalendar date/datetime to datetime."""
    from datetime import date
    if isinstance(dt_val, datetime):
        return dt_val.replace(tzinfo=timezone.utc) if dt_val.tzinfo is None else dt_val
    if isinstance(dt_val, date):
        return datetime(dt_val.year, dt_val.month, dt_val.day, tzinfo=timezone.utc)
    return datetime.now(tz=timezone.utc)


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------

def _abs(href: str, base_url: str) -> str:
    from urllib.parse import urljoin
    return urljoin(base_url, href)


def _first_tag(container, selectors):
    for sel in selectors:
        tag = container.select_one(sel)
        if tag:
            return tag
    return None


def _first_text(container, selectors) -> str:
    tag = _first_tag(container, selectors)
    return tag.get_text(strip=True) if tag else ""
