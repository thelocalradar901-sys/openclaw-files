"""
openclaw.py — Main daemon for The Local Radar event aggregation.

Scheduler jobs:
  - Ticketmaster: every 1 hour  (DMA-based structured API)
  - HTML auto:    every 2 hours (universal scraper with AI fallback)

Sources are loaded from sources.json — add a venue there, not here.
"""

import json
import logging
import os
import sys
from pathlib import Path

from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.interval import IntervalTrigger

import db
from scraper_ticketmaster import scrape_ticketmaster
from scraper_auto import scrape_source

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("/var/log/openclaw/openclaw.log"),
    ],
)
logger = logging.getLogger("openclaw")

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

BASE_DIR = Path(__file__).parent
SOURCES_FILE = BASE_DIR / "sources.json"

DB_CONFIG = {
    "host": os.environ.get("DB_HOST", "localhost"),
    "port": int(os.environ.get("DB_PORT", 3306)),
    "user": os.environ.get("DB_USER", ""),
    "password": os.environ.get("DB_PASSWORD", ""),
    "database": os.environ.get("DB_NAME", ""),
}

WP_TABLE_PREFIX = os.environ.get("WP_TABLE_PREFIX", "wp_")


# ---------------------------------------------------------------------------
# Source loading
# ---------------------------------------------------------------------------

def load_sources() -> list[dict]:
    with open(SOURCES_FILE) as f:
        sources = json.load(f)
    enabled = [s for s in sources if s.get("enabled", True)]
    logger.info(f"Loaded {len(enabled)} enabled sources from sources.json")
    return enabled


# ---------------------------------------------------------------------------
# Job runners
# ---------------------------------------------------------------------------

def run_ticketmaster_jobs(sources: list[dict]):
    tm_sources = [s for s in sources if s["type"] == "ticketmaster"]
    logger.info(f"Running Ticketmaster jobs for {len(tm_sources)} DMAs")
    conn = db.get_connection(DB_CONFIG)
    try:
        for source in tm_sources:
            try:
                events = scrape_ticketmaster(
                    dma_id=source["dma_id"],
                    city=source["city"],
                    api_key=os.environ.get("TM_API_KEY", ""),
                )
                _write_events(conn, events, source["name"])
            except Exception as exc:
                logger.error(f"Ticketmaster [{source['name']}] failed: {exc}")
    finally:
        conn.close()


def run_html_jobs(sources: list[dict]):
    html_sources = [s for s in sources if s["type"] == "html_auto"]
    logger.info(f"Running HTML auto-scrape jobs for {len(html_sources)} sources")
    conn = db.get_connection(DB_CONFIG)
    try:
        for source in html_sources:
            try:
                events = scrape_source(source)
                _write_events(conn, events, source["name"])
            except Exception as exc:
                logger.error(f"HTML scrape [{source['name']}] failed: {exc}")
    finally:
        conn.close()


def _write_events(conn, events: list[dict], source_name: str):
    if not events:
        logger.info(f"[{source_name}] No events to write")
        return
    written = 0
    skipped = 0
    for event in events:
        try:
            result = db.upsert_event(conn, event, table_prefix=WP_TABLE_PREFIX)
            if result == "inserted":
                written += 1
            else:
                skipped += 1
        except Exception as exc:
            logger.warning(f"[{source_name}] DB write error for '{event.get('title')}': {exc}")
    logger.info(f"[{source_name}] {written} inserted, {skipped} skipped (duplicates)")


# ---------------------------------------------------------------------------
# Scheduler setup
# ---------------------------------------------------------------------------

def main():
    logger.info("OpenClaw starting up...")
    db.ensure_schema(db.get_connection(DB_CONFIG), WP_TABLE_PREFIX)

    sources = load_sources()

    scheduler = BlockingScheduler(timezone="UTC")

    # Ticketmaster: run immediately on start, then every hour
    scheduler.add_job(
        run_ticketmaster_jobs,
        trigger=IntervalTrigger(hours=1),
        args=[sources],
        id="ticketmaster",
        name="Ticketmaster DMA pull",
        next_run_time=__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
    )

    # HTML auto-scraper: run 5 min after start, then every 2 hours
    import datetime
    startup_delay = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(minutes=5)
    scheduler.add_job(
        run_html_jobs,
        trigger=IntervalTrigger(hours=2),
        args=[sources],
        id="html_auto",
        name="Universal HTML scraper",
        next_run_time=startup_delay,
    )

    logger.info("Scheduler started. Jobs:")
    for job in scheduler.get_jobs():
        logger.info(f"  {job.name} — next run: {job.next_run_time}")

    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        logger.info("OpenClaw shutting down.")


if __name__ == "__main__":
    main()
